class IntConstants {
  static final int BOARD_MERIT_NO = 1;
  static final int BOARD_NEET_MARKS = 2;
  static final int BOARD_ALL_INDIA_RANK = 3;

  static final int MCC = 0;
  static final int AIIMS = 1;
  static final int JIPMER = 2;
  static final int ICAR = 3;
  static final int NEET = 4;

  static final int MEDICAL = 0;
  static final int PARAMEDICAL = 1;
  static final int PHARMACY = 2;
  static final int AGRICULTURE = 3;
  static final int BSC = 4;
}
